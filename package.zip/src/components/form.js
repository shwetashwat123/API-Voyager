import { MenuItem, Select, Box, TextField, Button } from "@mui/material";




function Form() {
    return (
        <>

            <Box sx={{
                display: 'flex',
                justifyContent: 'center',
                marginBottom: "-4px",
                width: '100vw',


            }}>
                <Select

                    label="Post"
                    sx={{
                        width: '140px',
                        height: '40px'

                    }}
                    size="small"
                >
                    <MenuItem size="small" value={'Post'}>POST</MenuItem>
                    <MenuItem value={'Get'}>GET</MenuItem>

                </Select>
                <TextField size="small" id="outlined-basic" label="Enter URL or Paste Text" variant="outlined" sx={{ width: '50%', fontSize: '2px' }} />
                <Button variant="contained" sx={{ padding: '15px', marginLeft: '4px', height: '40px' }}>Send</Button>
            </Box>

        </>
    )
}
export default Form;
