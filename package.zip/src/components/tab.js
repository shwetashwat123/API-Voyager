
import Box from '@mui/material/Box';
import { Tab, Tabs } from '@mui/material';
import { useState } from 'react';
function NewTabs() {

  const [value, setValue] = useState("")

  const handleChange = (event, newValue) => {
    setValue(newValue)
  }
  return (
    <Box sx={{
    width:'50%',
    textAlign:'center',
    margin:'auto',
    marginLeft:'275px',
    marginTop:'5px'
    }}>
      <Tabs TabIndicatorProps={{height:4,bottom:'20'}}  sx={{height:'2px'}} value={value} onChange={handleChange} aria-label="basic tabs example">
        <Tab label="Params" />
        <Tab label="Header" />
        <Tab label="Body" />
      </Tabs>
      <Box sx={{display:'flex'}}>
      <Box role="tabpanel"
        hidden={value !== 0}
        id={`simple-tabpanel-${0}`}
        aria-labelledby={`simple-tab-${0}`}>
        Params

      </Box>
      <Box role="tabpanel"
        hidden={value !== 1}
        id={`simple-tabpanel-${1}`}
        aria-labelledby={`simple-tab-${1}`}>
        Header

      </Box>
      <Box role="tabpanel"
        hidden={value !== 2}
        id={`simple-tabpanel-${2}`}
        aria-labelledby={`simple-tab-${2}`}>
        Body

      </Box>
      </Box>
    </Box >


  )

}
export default NewTabs;