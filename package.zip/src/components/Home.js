import  Header  from "./header";
import Form from "./form";
import NewTabs from "./tab";
import { Box } from "@mui/material";
function Home(){
    return(
        <>
       
        <Header/>
        <Form/>
        <NewTabs/>
        
        </>
    )
}
export default Home;