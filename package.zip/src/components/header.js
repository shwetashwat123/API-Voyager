import { makeStyles } from "@mui/styles"
const useStyles = makeStyles({
    logo: {
        width: 150,
        height: 50,
        padding: 4
    }
});

function Header() {


    const image = useStyles();


    const logo = "https://mms.businesswire.com/media/20230322005274/en/761650/23/postman-logo-vert-2018.jpg";


    return (
        <>
            <img src={logo} className={image.logo} />
        </>
    )
}
export default Header;